title: latke框架学习（一）
date: '2019-10-15 00:34:33'
updated: '2019-10-15 00:34:33'
tags: [开源]
permalink: /articles/2019/10/15/1571070873224.html
---
![](https://img.hacpai.com/bing/20181018.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 简介
[Latke](https://github.com/b3log/latke)（'lɑ:tkə，土豆饼）是一个简单易用的 Java Web 应用开发框架，包含 MVC、IoC、事件通知、ORM、插件等组件。
在实体模型上使用 JSON 贯穿前后端，使应用开发更加快捷。这是 Latke 不同于其他框架的地方，比较适合小型应用的快速开发。
